package com.library.login;

public interface LoginService {
	public LoginDTO login_act(String mem_id, String mem_pw);
}
