package com.library.join;

public interface JoinService {
	public void join(String mem_id, String mem_pw, String mem_name, String mem_birth, String mem_tel, String mem_email, String mem_addr, String mem_bebook, String mem_rebook);
}
