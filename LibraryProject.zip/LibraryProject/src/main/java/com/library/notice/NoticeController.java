package com.library.notice;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class NoticeController {
	@RequestMapping("/notice")
	public String notice() {
		
		return "notice";
	}
}
