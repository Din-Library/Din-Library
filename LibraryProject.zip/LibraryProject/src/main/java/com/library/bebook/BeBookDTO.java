package com.library.bebook;

public class BeBookDTO {
	String isbn, title, description, cover, author, categoryName, publisher, pubDate;
	int mem_no;
	String mem_id;
	public BeBookDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BeBookDTO(String isbn, String title, String description, String cover, String author, String categoryName,
			String publisher, String pubDate) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.description = description;
		this.cover = cover;
		this.author = author;
		this.categoryName = categoryName;
		this.publisher = publisher;
		this.pubDate = pubDate;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCover() {
		return cover;
	}
	public void setCover(String cover) {
		this.cover = cover;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getPubDate() {
		return pubDate;
	}
	public void setPubDate(String pubDate) {
		this.pubDate = pubDate;
	}
	public int getMem_no() {
		return mem_no;
	}
	public void setMem_no(int mem_no) {
		this.mem_no = mem_no;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	
	
	
}
