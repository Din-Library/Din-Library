package com.library.bebook;

import java.util.ArrayList;

public interface BeBookService {
	public void book_insert(String isbn, String title, int mem_no, String mem_id);
	public ArrayList<BeBookDTO> book_check(String isbn);
	public Integer book_full(int mem_no);
}
